# LoTC Character Journal — project instructions

Read README.md, docs/STATUS.md, docs/DECISIONS.md, and docs/MILESTONES.md first.
Target Minecraft 1.21.11, Fabric, Java 21. Do not silently upgrade Minecraft.

## Workflow
- Work on the current milestone until its automated criteria pass.
- Use a coordinator and narrowly scoped subagents for independent implementation,
  verification, or review when parallel work is requested. Assign non-overlapping
  files or use separate worktrees. Only the coordinator integrates changes.
- Keep interfaces explicit. No global service locator or central all-purpose manager.
- Prefer small coherent features; do not create empty modules merely to fill a chart.
- Run ./gradlew check :fabric:build. For plain logic, use the narrow module tests first.
- Run ./gradlew :fabric:runClientGameTest only in an environment prepared to launch
  Minecraft, with its EULA accepted by the user. Never call compilation an in-game test.
- Review failures independently where possible. After three unsuccessful repair
  cycles, document the blocker and reassess; do not weaken acceptance criteria.
- Do not change checked reference expectations just to match implementation.
- Record exact commands, outcomes, skipped checks, and user testing still needed
  in docs/STATUS.md. Preserve milestone state across sessions.

## Boundaries
- domain: contracts and models, no external dependencies.
- parsing: domain only; uncertain channels and identities remain unresolved.
- application: domain only; injected ports and bounded worker queues.
- storage: domain only; owns SQL, schema migration, and backups.
- fabric: Minecraft adapter and composition root; keep feature logic outside it.
- Future identity, encounter, statistics, analysis, and provider features get
  coherent modules as implemented; provider-specific details stay at the edges.
- Keep file, SQL, and network operations off the client/render thread.

## Data rules
- Never add real RP logs, databases, secrets, tokens, or user identifiers to Git,
  generated fixtures, screenshots for distribution, or source archives.
- Use synthetic log samples with realistic formatting.
- PM, OOC, unknown channels, and other-persona knowledge cannot enter AI analysis.
- Store original observations separately from interpretations; preserve provenance.
- Identity merges require user confirmation and must be reversible.
- AI defaults off. Never silently fall back to a paid provider.
- Never run unattended tests against the live LoTC server.
- Do not overwrite the previous chat database. Import it read-only in a later phase.

Do not claim missing features are implemented. User testing is a distinct status.

